import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.scss']
})
export class RegistroComponent implements OnInit {
  formRegistro!: FormGroup;
  enviado = false;
  carregando = false;
  senhaVisivel = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.formRegistro = this.formBuilder.group({
      nome: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      senha: ['', Validators.required],
      cartaoID: ['', Validators.required],
      whats: ['', Validators.required],
    });
  }

  // Facilita o acesso aos controles do formulário
  get f() { return this.formRegistro.controls; }

  onSubmit() {
    this.enviado = true;

    // Para aqui se o formulário é inválido
    if (this.formRegistro.invalid) {
      return;
    }

    this.carregando = true;

    const dadosRegistro = {
      nome: this.f['nome'].value,
      email: this.f['email'].value,
      senha: this.f['senha'].value,
      cartaoID: this.f['cartaoID'].value,
      whats: this.f['whats'].value,
    };

    this.http.post('http://localhost:3000/autenticacao/registro', dadosRegistro)
      .subscribe({
        next: data => {
          this.snackBar.open('Registro bem-sucedido!', 'Fechar', { duration: 5000 });
          this.router.navigate(['/login']);
        },
        error: error => {
          this.snackBar.open('Erro no registro. Por favor, tente novamente.', 'Fechar', { duration: 5000 });
          this.carregando = false;
        }
      });
  }
}
